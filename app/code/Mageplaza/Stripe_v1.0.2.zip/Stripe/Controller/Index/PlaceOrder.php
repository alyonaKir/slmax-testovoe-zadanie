<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Controller\Index;

use Exception;
use InvalidArgumentException;
use Magento\Checkout\Helper\Data;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\Type\Onepage;
use Magento\Customer\Model\Group;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Registry;
use Magento\Quote\Api\CartManagementInterface;
use Magento\Quote\Model\Quote;
use Mageplaza\Stripe\Model\Payment\Alipay;
use Psr\Log\LoggerInterface;
use Stripe\Source;
use Stripe\Stripe;

/**
 * Class PlaceOrder
 * @package Mageplaza\Stripe\Controller\Index
 */
class PlaceOrder extends Action
{
    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var CartManagementInterface
     */
    private $cartManagement;

    /**
     * @var Session
     */
    private $customerSession;

    /**
     * @var Data
     */
    private $checkoutHelper;

    /**
     * @var string
     */
    protected $sourceId = '';

    /**
     * @var Alipay
     */
    protected $alipay;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * PlaceOrder constructor.
     *
     * @param Context $context
     * @param CartManagementInterface $cartManagement
     * @param Data $checkoutHelper
     * @param Session $checkoutSession
     * @param CustomerSession $customerSession
     * @param Registry $registry
     * @param Alipay $alipay
     * @param LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        CartManagementInterface $cartManagement,
        Data $checkoutHelper,
        Session $checkoutSession,
        CustomerSession $customerSession,
        Registry $registry,
        Alipay $alipay,
        LoggerInterface $logger
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartManagement  = $cartManagement;
        $this->checkoutHelper  = $checkoutHelper;
        $this->alipay          = $alipay;
        $this->customerSession = $customerSession;
        $this->registry        = $registry;
        $this->logger          = $logger;

        parent::__construct($context);
    }

    /**
     * @param RequestInterface $request
     *
     * @return ResponseInterface|Redirect
     * @throws NotFoundException
     */
    public function dispatch(RequestInterface $request)
    {
        $this->sourceId = $request->getParam('source');

        if (!$this->sourceId) {
            $this->_actionFlag->set('', self::FLAG_NO_DISPATCH, true);
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('noRoute');

            return $resultRedirect;
        }

        return parent::dispatch($request);
    }

    /**
     * @return ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $quote          = $this->checkoutSession->getQuote();
        $secretKey      = $quote->getPayment()->getMethodInstance()->getConfigData('secret_key');
        Stripe::setApiKey($secretKey);
        $source = Source::retrieve($this->sourceId);
        if ($source['status'] === 'failed') {
            return $resultRedirect->setPath('checkout/cart');
        }

        try {
            $this->registry->register('source_id', $this->sourceId);
            if (!$quote || !$quote->getItemsCount()) {
                throw new InvalidArgumentException(__('Checkout failed to initialize. Verify and try again.'));
            }
            if ($this->getCheckoutMethod($quote) === Onepage::METHOD_GUEST) {
                $this->prepareGuestQuote($quote);
            }

            $this->disabledQuoteAddressValidation($quote);

            $quote->collectTotals();

            $this->cartManagement->placeOrder($quote->getId());

            return $resultRedirect->setPath('checkout/onepage/success');
        } catch (Exception $e) {
            $this->logger->critical($e);
            $this->messageManager->addExceptionMessage($e, $e->getMessage());
        }

        return $resultRedirect->setPath('checkout/cart');
    }

    /**
     * Make sure addresses will be saved without validation errors
     *
     * @param Quote $quote
     *
     * @return void
     */
    protected function disabledQuoteAddressValidation(Quote $quote)
    {
        $billingAddress = $quote->getBillingAddress();
        $billingAddress->setShouldIgnoreValidation(true);

        if (!$quote->getIsVirtual()) {
            $shippingAddress = $quote->getShippingAddress();
            $shippingAddress->setShouldIgnoreValidation(true);
            if (!$billingAddress->getEmail()) {
                $billingAddress->setSameAsBilling(1);
            }
        }
    }

    /**
     * Get checkout method
     *
     * @param Quote $quote
     *
     * @return string
     */
    private function getCheckoutMethod(Quote $quote)
    {
        if ($this->customerSession->isLoggedIn()) {
            return Onepage::METHOD_CUSTOMER;
        }
        if (!$quote->getCheckoutMethod()) {
            if ($this->checkoutHelper->isAllowedGuestCheckout($quote)) {
                $quote->setCheckoutMethod(Onepage::METHOD_GUEST);
            } else {
                $quote->setCheckoutMethod(Onepage::METHOD_REGISTER);
            }
        }

        return $quote->getCheckoutMethod();
    }

    /**
     * Prepare quote for guest checkout order submit
     *
     * @param Quote $quote
     *
     * @return void
     */
    private function prepareGuestQuote(Quote $quote)
    {
        $quote->setCustomerId(null)
            ->setCustomerEmail($quote->getBillingAddress()->getEmail())
            ->setCustomerIsGuest(true)
            ->setCustomerGroupId(Group::NOT_LOGGED_IN_ID);
    }
}

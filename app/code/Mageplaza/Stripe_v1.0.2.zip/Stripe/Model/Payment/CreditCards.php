<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model\Payment;

use Mageplaza\Stripe\Model\StripePayment;

/**
 * Class CreditCards
 * @package Mageplaza\Stripe\Model\Payment
 */
class CreditCards extends StripePayment
{
    const CODE  = 'mp_stripe_credit_cards';
    const VCODE = 'mp_stripe_credit_cards_vault';

    /**
     * @var string
     */
    protected $_code = self::CODE;

    /**
     * @return array
     */
    public function getCCTypes()
    {
        return $this->configToArray($this->getConfigData('cctypes'));
    }

    /**
     * @param null $storeId
     *
     * @return mixed
     */
    public function isSecure($storeId = null)
    {
        return (bool) $this->getConfigData('secure', $storeId);
    }

    /**
     * @param null $storeId
     *
     * @return mixed
     */
    public function isForceUsing($storeId = null)
    {
        return (bool) $this->getConfigData('force_using', $storeId);
    }

    /**
     * @param null $storeId
     *
     * @return mixed
     */
    public function getSecureWhen($storeId = null)
    {
        return $this->configToArray($this->getConfigData('secure_when', $storeId));
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        return [
            'creditCardTypes' => $this->getCCTypes(),
            'isSecure'        => $this->isSecure(),
            'foreUsing'       => $this->isForceUsing(),
            'placeOrderTitle' => $this->getPlaceOrderTitle(),
            'secureWhen'      => $this->getSecureWhen(),
            'return_url'      => $this->getReturnUrl(),
            'instructions'    => $this->getInstructions()
        ];
    }
}

<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model\InstantPurchase\CreditCard;

use InvalidArgumentException;
use Magento\InstantPurchase\PaymentMethodIntegration\PaymentTokenFormatterInterface;
use Magento\Vault\Api\Data\PaymentTokenInterface;
use Mageplaza\Stripe\Model\Source\CardType;

/**
 * Class TokenFormatter
 * @package Mageplaza\Stripe\Model\InstantPurchase\CreditCard
 */
class TokenFormatter implements PaymentTokenFormatterInterface
{
    /**
     * @var CardType
     */
    protected $cardType;

    /**
     * TokenFormatter constructor.
     *
     * @param CardType $cardType
     */
    public function __construct(CardType $cardType)
    {
        $this->cardType = $cardType;
    }

    /**
     * @param PaymentTokenInterface $paymentToken
     *
     * @return string
     * @throws InvalidArgumentException
     */
    public function formatPaymentToken(PaymentTokenInterface $paymentToken): string
    {
        $details = json_decode($paymentToken->getTokenDetails() ?: '{}', true);
        if (!isset($details['type'], $details['maskedCC'], $details['expirationDate'])) {
            throw new InvalidArgumentException('Invalid Stripe credit card token details.');
        }

        $mapperCard = array_flip($this->cardType->getCardMapper());
        if (isset($mapperCard[$details['type']])) {
            $ccType = $mapperCard[$details['type']];
        } else {
            $ccType = $details['type'];
        }

        $formatted = sprintf(
            '%s: %s, %s: %s (%s: %s)',
            __('Credit Card'),
            $ccType,
            __('ending'),
            $details['maskedCC'],
            __('expires'),
            $details['expirationDate']
        );

        return $formatted;
    }
}

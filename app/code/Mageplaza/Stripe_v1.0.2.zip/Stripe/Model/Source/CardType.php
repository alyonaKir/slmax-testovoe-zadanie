<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class CardType
 * @package Mageplaza\Stripe\Model\Source
 */
class CardType implements ArrayInterface
{
    const AMERICAN_EXPRESS = 'amex';
    const VISA             = 'visa';
    const MASTERCARD       = 'mastercard';
    const DISCOVER         = 'discover';
    const JCB              = 'jcb';
    const DINERS           = 'diners';
    const UNIONPAY         = 'unionpay';

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::AMERICAN_EXPRESS,
                'label' => 'American Express',
            ],
            [
                'value' => self::VISA,
                'label' => 'Visa'
            ],
            [
                'value' => self::MASTERCARD,
                'label' => 'MasterCard',
            ],
            [
                'value' => self::DISCOVER,
                'label' => 'Discover'
            ],
            [
                'value' => self::JCB,
                'label' => 'JCB',
            ],
            [
                'value' => self::DINERS,
                'label' => 'Diners'
            ],
            [
                'value' => self::UNIONPAY,
                'label' => 'UnionPay'
            ]
        ];
    }

    /**
     * @param string $code
     *
     * @return mixed
     */
    public function getCreditCardsMapper($code)
    {
        $mapper = $this->getCardMapper();

        return isset($mapper[$code]) ? $mapper[$code] : '';
    }

    /**
     * @return array
     */
    public function getCardMapper()
    {
        return [
            'Visa'             => 'VI',
            'JCB'              => 'JCB',
            'UnionPay'         => 'UN',
            'Discover'         => 'DI',
            'MasterCard'       => 'MC',
            'Diners Club'      => 'DN',
            'American Express' => 'AE'
        ];
    }
}

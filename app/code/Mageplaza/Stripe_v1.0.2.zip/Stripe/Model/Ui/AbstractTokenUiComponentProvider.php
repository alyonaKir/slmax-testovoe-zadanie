<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model\Ui;

use Magento\Framework\UrlInterface;
use Magento\Vault\Api\Data\PaymentTokenInterface;
use Magento\Vault\Model\Ui\TokenUiComponentInterface;
use Magento\Vault\Model\Ui\TokenUiComponentInterfaceFactory;
use Magento\Vault\Model\Ui\TokenUiComponentProviderInterface;
use Mageplaza\Stripe\Model\Payment\CreditCards;

/**
 * Class AbstractTokenUiComponentProvider
 * @package Mageplaza\Stripe\Model\Ui
 */
abstract class AbstractTokenUiComponentProvider implements TokenUiComponentProviderInterface
{
    /**
     * @var TokenUiComponentInterfaceFactory
     */
    private $componentFactory;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @param TokenUiComponentInterfaceFactory $componentFactory
     * @param UrlInterface $urlBuilder
     */
    public function __construct(TokenUiComponentInterfaceFactory $componentFactory, UrlInterface $urlBuilder)
    {
        $this->componentFactory = $componentFactory;
        $this->urlBuilder       = $urlBuilder;
    }

    /**
     * Get UI component for token
     *
     * @param PaymentTokenInterface $paymentToken
     *
     * @return TokenUiComponentInterface
     */
    public function getComponentForToken(PaymentTokenInterface $paymentToken)
    {
        $jsonDetails = json_decode($paymentToken->getTokenDetails() ?: '{}', true);
        $data        = [
            'config' => [
                'code'                                                   => CreditCards::VCODE,
                TokenUiComponentProviderInterface::COMPONENT_DETAILS     => $jsonDetails,
                TokenUiComponentProviderInterface::COMPONENT_PUBLIC_HASH => $paymentToken->getPublicHash()
            ],
            'name'   => $this->getName()
        ];
        if ($this->getTemplate()) {
            $data['config']['template'] = $this->getTemplate();
        }

        if ($this->get3dSecureUrl()) {
            $data['config']['secureUrl'] = $this->get3dSecureUrl();
        }

        return $this->componentFactory->create($data);
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'Mageplaza_Stripe/js/view/payment/method-renderer/vault';
    }

    /**
     * @return string
     */
    public function getTemplate()
    {
        return '';
    }

    /**
     * @return string
     */
    public function get3dSecureUrl()
    {
        return '';
    }
}

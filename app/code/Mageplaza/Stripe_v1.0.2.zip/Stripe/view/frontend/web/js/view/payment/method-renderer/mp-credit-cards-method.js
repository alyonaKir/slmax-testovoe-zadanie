/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'Mageplaza_Stripe/js/view/payment/method-renderer/mp-method',
        'Magento_Checkout/js/model/full-screen-loader',
        'mage/translate',
        'Mageplaza_Stripe/js/model/stripe-method',
        'Magento_Vault/js/view/payment/vault-enabler'
    ],
    function (Component, Loader, Translate, StripeModel, VaultEnabler) {
        'use strict';
        var mpStripeCreditCards = window.checkoutConfig.payment.mp_stripe_credit_cards;

        return Component.extend({
            ccTypesSupport: mpStripeCreditCards.creditCardTypes,
            card: '',
            source: '',
            isValid: false,
            type: 'three_d_secure',
            /**
             * @returns {exports.initialize}
             */
            initialize: function () {
                this._super();
                this.vaultEnabler = new VaultEnabler();
                this.vaultEnabler.setPaymentCode(
                    'mp_stripe_credit_cards_vault'
                );

                return this;
            },

            /**
             * @returns {Boolean}
             */
            isVaultEnabled: function () {
                return this.vaultEnabler.isVaultEnabled();
            },

            createInputCard: function () {
                var self = this;
                var style = {
                    base: {
                        color: '#32325d',
                        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                        fontSmoothing: 'antialiased',
                        fontSize: '16px',
                        '::placeholder': {
                            color: '#aab7c4'
                        }
                    },
                    invalid: {
                        color: '#fa755a',
                        iconColor: '#fa755a'
                    }
                };

                this.card = this.mpStripe.elements().create('card', {style: style, hidePostalCode: true});
                this.card.mount('#mp-card');

                this.card.addEventListener('change', function (response) {
                    var displayError = document.getElementById('card-errors');

                    if (self.ccTypesSupport.indexOf(response.brand) === -1) {
                        response.error = {
                            message: Translate("The brand unknown.")
                        };
                    }

                    if (response.error) {
                        self.isValid = false;
                        displayError.textContent = response.error.message;
                    } else {
                        self.isValid = true;
                        displayError.textContent = '';
                    }
                });
            },

            /**
             * @returns {boolean}
             */
            validate: function () {
                return this.isValid && this.source;
            },

            /**
             * @returns {{method, po_number: null, additional_data: {}}}
             */
            getData: function () {
                var data = this._super();
                data = this.setCardInfo(data, this.source);
                this.vaultEnabler.visitAdditionalData(data);

                return data;
            },

            /**
             * @returns {exports}
             */
            mpStripePlaceOrder: function () {
                if (this.isValid) {
                    event.preventDefault();
                    Loader.startLoader();
                    var self = this;

                    this.mpStripe.createSource(this.card, StripeModel.getSourceAddress()).then(function (result) {
                        var errorElement = document.getElementById('card-errors');

                        if (result.error) {
                            errorElement.textContent = result.error.message;
                        } else {
                            self.source = result.source;
                            if (mpStripeCreditCards.isSecure) {

                                var status = StripeModel.process3DSecure(
                                    result,
                                    self.messageContainer,
                                    mpStripeCreditCards,
                                    self.getData()
                                );

                                if (!status.isShowMessage && !status.isPlace3D) {
                                    self.placeOrder();
                                }

                            } else {
                                self.placeOrder();
                            }
                        }
                        Loader.stopLoader();
                    });
                } else {
                    this.messageContainer.addErrorMessage({
                        message: Translate('Please fill valid credit card numbers.')
                    });
                }

                return this;
            }
        });
    }
);
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery',
        'ko',
        'Mageplaza_Stripe/js/view/payment/method-renderer/mp-method',
        'Mageplaza_Stripe/js/model/stripe-method',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Magento_Checkout/js/action/redirect-on-success'
    ],
    function ($, ko, Component, StripeModel, Quote, additionalValidators, redirectOnSuccessAction) {
        'use strict';

        return Component.extend({
            type: 'request-button',
            source: {},
            isShowButton: ko.observable(true),
            initialize: function () {
                this._super();

                if (this.isOscPage()) {
                    var self = this;
                    Quote.paymentMethod.subscribe(function (value) {
                        self.isDisplayButton(value);
                    });
                }
            },

            /**
             * @returns {{method, po_number: null, additional_data: {}}}
             */
            getData: function () {
                var data = this._super();
                return this.setCardInfo(data, this.source);
            },

            /**
             * @returns {boolean}
             */
            isOscPage: function () {
                return !!window.checkoutConfig.oscConfig;
            },

            /**
             * @param paymentMethod
             */
            isDisplayButton: function (paymentMethod) {
                var actionToolbarElement = $('#co-place-order-area > .osc-place-order-wrapper > .actions-toolbar');
                if (paymentMethod && paymentMethod.method === this.getCode()) {
                    actionToolbarElement.hide();
                    this.isShowButton(true);
                } else {
                    actionToolbarElement.show();
                    this.isShowButton(false);
                }
            },

            /**
             * @param response
             */
            placeOrderRequest: function (response) {
                this.placeOrderDeferred(response);
            },

            /**
             * @param response
             * @constructor
             */
            placeOrderDeferred: function (response) {
                var self = this;
                this.isPlaceOrderActionAllowed(false);

                this.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                            response.complete('fail');
                        }
                    ).done(
                    function () {
                        self.afterPlaceOrder();

                        if (self.redirectAfterPlaceOrder) {
                            response.complete('success');
                            redirectOnSuccessAction.execute();
                        }
                    }
                );
            },

            createButton: function () {
                var self = this;
                var paymentRequest = this.mpStripe.paymentRequest({
                    country: Quote.billingAddress().countryId,
                    currency: StripeModel.getCurrency(),
                    total: {
                        label: 'Summary',
                        amount: 0
                    }
                });

                var elements = this.mpStripe.elements();
                var prButton = elements.create('paymentRequestButton', {
                    paymentRequest: paymentRequest
                });

                prButton.addEventListener('click', function (e) {
                    if (self.validate() && additionalValidators.validate()) {
                        paymentRequest.update({
                            total: {
                                label: 'Pay',
                                amount: StripeModel.getAmount()
                            }
                        });
                    } else {
                        e.preventDefault();
                    }
                });

                paymentRequest.canMakePayment().then(function (result) {
                    if (result) {
                        prButton.mount('#payment-request-button');
                    } else {
                        self.isShowPayment(false);
                    }
                });

                paymentRequest.on('source', function (response) {
                    if (response.error) {
                        self.messageContainer.addErrorMessage(response.error);
                    } else {
                        self.source = response.source;
                        self.placeOrderRequest(response);
                    }
                });

                if (this.isOscPage()) {
                    var placeOrderRequestButtonElement = $('#co-place-order-area #payment-request-button');
                    if (placeOrderRequestButtonElement.length) {
                        placeOrderRequestButtonElement.remove();
                    }

                    $('#payment-request-button').detach().insertBefore('#co-place-order-area > .osc-place-order-wrapper > .osc-trust-seal');

                    self.isDisplayButton(Quote.paymentMethod());
                }
            }
        });
    }
);
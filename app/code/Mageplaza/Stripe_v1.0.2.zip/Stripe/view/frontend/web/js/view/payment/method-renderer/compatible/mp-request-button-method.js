/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery',
        'Mageplaza_Stripe/js/view/payment/method-renderer/mp-request-button-method',
        'Mageplaza_Osc/js/action/set-checkout-information'
    ],
    function ($, Component, setCheckoutInformationAction) {
        'use strict';

        return Component.extend({

            preparePlaceOrder: function () {
                var scrollTop = true;
                var deferer = $.when(setCheckoutInformationAction());

                return scrollTop ? deferer.done(function () {
                    $("body").animate({scrollTop: 0}, "slow");
                }) : deferer;
            },

            /**
             * @param response
             */
            placeOrderRequest: function (response) {
                var self = this;
                this.preparePlaceOrder().done(function () {
                    self.placeOrderDeferred(response);
                });
            }
        });
    }
);
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery',
        'Mageplaza_Stripe/js/view/payment/method-renderer/mp-method',
        'Mageplaza_Stripe/js/model/stripe-method',
        'mage/translate'
    ],
    function ($, Component, StripeModel, Translate) {
        'use strict';

        return Component.extend({
            type: 'ideal',
            idealBank: '',
            isValid: false,
            createInputIDEAL: function () {
                var elements = this.mpStripe.elements();
                var style = {
                    base: {
                        padding: '10px 12px',
                        color: '#32325d',
                        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
                        fontSmoothing: 'antialiased',
                        fontSize: '16px',
                        '::placeholder': {
                            color: '#aab7c4'
                        }
                    },
                    invalid: {
                        color: '#fa755a'
                    }
                };

                this.idealBank = elements.create('idealBank', {style: style});

                this.idealBank.mount('#ideal-bank-element');
                var self = this;
                this.idealBank.on('change', function (response) {
                    var displayError = document.getElementById('ideal-errors');

                    if (response.error) {
                        self.isValid = false;
                        displayError.textContent = response.error.message;
                    } else {
                        self.isValid = true;
                        displayError.textContent = '';
                    }
                });
            },

            /**
             * @returns {exports}
             */
            mpStripePlaceOrder: function (data, event) {
                if (this.isValid) {
                    if (event) {
                        event.preventDefault();
                    }

                    StripeModel.setIdealBank(this.idealBank);
                    StripeModel.createSource(this.messageContainer, this.getData(), this.type, this.returnUrl, false, '');
                } else {
                    this.messageContainer.addErrorMessage({
                        message: Translate('Please select bank')
                    });
                }

                return this;
            }
        });
    }
);
<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Mageplaza\Stripe\Model\Payment\IDEAL;
use Mageplaza\Stripe\Model\Source\PaymentAction;
use Stripe\Charge;
use Stripe\Customer;
use Stripe\Refund;
use Stripe\Source;
use Stripe\Stripe;

/**
 * Class ClientMock
 * @package Mageplaza\Stripe\Gateway\Http\Client
 */
class ClientMock implements ClientInterface
{
    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param Logger $logger
     */
    public function __construct(
        Logger $logger
    ) {
        $this->logger = $logger;
    }

    /**
     * Places request to gateway. Returns result as ENV array
     *
     * @param TransferInterface $transferObject
     *
     * @return array
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $response = $transferObject->getBody();
        if (isset($response['PRIVATE_KEY']) && $response['PRIVATE_KEY']) {
            Stripe::setApiKey($response['PRIVATE_KEY']);
        }

        if ($response['TXN_TYPE'] === PaymentAction::ACTION_AUTHORIZE_CAPTURE) {
            $chargeData = [
                'amount'      => $response['AMOUNT'],
                'currency'    => $response['CURRENCY'],
                'description' => $response['DESCRIPTION'],
                'source'      => $response['SOURCE_ID']
            ];

            $chargeData         = $this->getCustomerId($chargeData);
            $charge             = Charge::create($chargeData);
            $response['TXN_ID'] = $charge['id'];
            $response           = $this->addIDIALInfo($response, $charge);
        }

        if ($response['TXN_TYPE'] === 'refund') {
            $charge = Refund::create([
                'charge' => $response['SOURCE_ID'],
            ]);

            $response['TXN_ID'] = $charge['id'];
        }

        $this->logger->debug(
            [
                'request'  => $transferObject->getBody(),
                'response' => $response
            ]
        );

        return $response;
    }

    /**
     * Get customer id on stripe account
     *
     * @param $chargeData
     *
     * @return mixed
     */
    public function getCustomerId($chargeData)
    {
        $source = Source::retrieve($chargeData['source']);
        if (!isset($source['customer'])) {
            $customer               = Customer::create(
                [
                    'email'  => $source['owner']['email'],
                    'source' => $chargeData['source']
                ]
            );
            $chargeData['customer'] = $customer['id'];
        } else {
            $chargeData['customer'] = $source['customer'];
        }

        return $chargeData;
    }

    /**
     * @param $response
     * @param $charge
     *
     * @return mixed
     */
    public function addIDIALInfo($response, $charge)
    {
        if (isset($response['METHOD_CODE']) &&
            IDEAL::CODE === $response['METHOD_CODE'] &&
            isset($charge['payment_method_details']['ideal'])
        ) {
            $response['IDIAL_INFO'] = $charge['payment_method_details']['ideal'];
        }

        return $response;
    }
}

<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway;

use InvalidArgumentException;
use Magento\Framework\Registry;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Sales\Model\Order;
use Mageplaza\Stripe\Model\Source\PaymentAction;
use Stripe\Source;
use Stripe\Stripe;
use Stripe\StripeObject;

/**
 * Class AbstractRequest
 * @package Mageplaza\Stripe\Gateway\Request
 */
abstract class AbstractGateway implements BuilderInterface, HandlerInterface
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var array
     */
    protected $subjectData = [];

    /**
     * @var string
     */
    protected $secretKey = '';

    /**
     * AuthorizationRequest constructor.
     *
     * @param Registry $registry
     */
    public function __construct(Registry $registry)
    {
        $this->registry = $registry;
    }

    /**
     * @param array $subject
     */
    public function validatePayment($subject)
    {
        if (!isset($subject['payment'])
            || !$subject['payment'] instanceof PaymentDataObjectInterface
        ) {
            throw new InvalidArgumentException(__('Payment data object should be provided'));
        }

        $this->subjectData = $subject;
    }

    /**
     * @param array $buildSubject
     *
     * @return PaymentDataObjectInterface
     */
    public function getPayment($buildSubject)
    {
        $this->validatePayment($buildSubject);
        /** @var PaymentDataObjectInterface $payment */
        $paymentDataObject = $buildSubject['payment'];

        return $paymentDataObject->getPayment();
    }

    /**
     * @inheritdoc
     */
    public function build(array $buildSubject)
    {
        $payment = $this->getPayment($buildSubject);
        /** @var PaymentDataObjectInterface $payment */
        $paymentDataObject = $buildSubject['payment'];
        $order             = $paymentDataObject->getOrder();

        return $this->processRequest($payment, $order);
    }

    /**
     * @inheritdoc
     */
    public function handle(array $handlingSubject, array $response)
    {
        $payment = $this->getPayment($handlingSubject);
        $this->processResponse($payment, $response);
    }

    /**
     * @param $payment
     * @param array $response
     *
     * @return $this
     */
    public function processResponse($payment, $response)
    {
        return $this;
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param Order $order
     *
     * @return array
     */
    public function processRequest($payment, $order)
    {
        return [];
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param StripeObject $cardInfo
     *
     * @return array
     */
    public function setCardInfo($payment, $cardInfo)
    {
        $additionalData = $payment->getAdditionalData();
        if (!is_array($additionalData)) {
            $additionalData = [];
        }
        $additionalData['source_id']         = $cardInfo['id'];
        $additionalData['mp_card_brand']     = $cardInfo['card']['brand'];
        $additionalData['mp_card_exp_month'] = $cardInfo['card']['exp_month'];
        $additionalData['mp_card_exp_year']  = $cardInfo['card']['exp_year'];
        $additionalData['mp_card_last4']     = $cardInfo['card']['last4'];
        $payment->setAdditionalInformation($additionalData);

        return $additionalData;
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param string $sourceId
     * @param null|string $storeId
     *
     * @return StripeObject
     */
    public function retrieveSource($payment, $sourceId, $storeId = null)
    {
        $this->secretKey = $this->getSecretKey($payment, $storeId);
        Stripe::setApiKey($this->secretKey);

        return Source::retrieve($sourceId);
    }

    /**
     * @param PaymentDataObjectInterface $payment
     *
     * @return mixed
     */
    public function getSourceId($payment)
    {
        $sourceId = $payment->getAdditionalInformation('source_id');
        if (!$sourceId) {
            $sourceId = $this->registry->registry('source_id');
            if (!$sourceId) {
                throw new InvalidArgumentException(__('source_id not found'));
            }
        }

        return $sourceId;
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param string $storeId
     *
     * @return mixed
     */
    public function getSecretKey($payment, $storeId)
    {
        if (!$this->secretKey) {
            return $payment->getMethodInstance()->getConfigData('secret_key', $storeId);
        }

        return $this->secretKey;
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param Order $order
     *
     * @return array
     */
    public function processData($payment, $order)
    {
        $extensionAttributes = $payment->getExtensionAttributes();
        $paymentToken        = $extensionAttributes->getVaultPaymentToken();
        $isSaveCard          = $payment->getAdditionalInformation('is_active_payment_token_enabler');
        if ($paymentToken) {
            $source   = $this->retrieveSource($payment, $paymentToken->getGatewayToken(), $order->getStoreId());
            $cardInfo = $this->setCardInfo($payment, $source);
            $sourceId = $cardInfo['source_id'];
        } else {
            $sourceId = $this->getSourceId($payment);
        }

        $type = $this->getType();
        if ($type === PaymentAction::ACTION_AUTHORIZE_CAPTURE) {
            $this->processCard($payment, $order, $sourceId);
        }

        return [
            'SOURCE_ID'    => $sourceId,
            'TXN_TYPE'     => $type,
            'IS_SAVE_CARD' => $isSaveCard
        ];
    }

    /**
     * @return string
     */
    public function getType()
    {
        return PaymentAction::ACTION_AUTHORIZE;
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param Order $order
     * @param string $sourceId
     */
    public function processCard($payment, $order, $sourceId)
    {
        $source = $this->retrieveSource($payment, $sourceId, $order->getStoreId());
        $card   = [];
        if ($source && isset($source['three_d_secure'])) {
            $card = $source['three_d_secure'];
        } elseif (isset($source['card'])) {
            $card = $source['card'];
        }

        if ($card) {
            $this->setCardInfo($payment, $source);
        }
    }
}

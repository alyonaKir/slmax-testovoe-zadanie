<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Mageplaza\Stripe\Model\Payment\CreditCards;
use Mageplaza\Stripe\Model\Source\Environment;

/**
 * Class Config
 * @package Mageplaza\Stripe\Gateway\Config
 */
class Config implements ConfigInterface
{
    const DEFAULT_PATH_PATTERN = 'payment/%s/%s';

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var string|null
     */
    private $methodCode;

    /**
     * @var string|null
     */
    private $pathPattern;

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @var EncryptorInterface
     */
    protected $_encryptor;

    /**
     * Config constructor.
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param EncryptorInterface $encryptor
     * @param Escaper $escaper
     * @param null $methodCode
     * @param string $pathPattern
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        EncryptorInterface $encryptor,
        Escaper $escaper,
        $methodCode = null,
        $pathPattern = self::DEFAULT_PATH_PATTERN
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_encryptor  = $encryptor;
        $this->methodCode  = $methodCode;
        $this->pathPattern = $pathPattern;
        $this->escaper     = $escaper;
    }

    /**
     * Sets method code
     *
     * @param string $methodCode
     *
     * @return void
     */
    public function setMethodCode($methodCode)
    {
        $this->methodCode = $methodCode;
    }

    /**
     * Sets path pattern
     *
     * @param string $pathPattern
     *
     * @return void
     */
    public function setPathPattern($pathPattern)
    {
        $this->pathPattern = $pathPattern;
    }

    /**
     * Retrieve information from payment configuration
     *
     * @param string $field
     * @param int|null $storeId
     *
     * @return mixed
     */
    public function getValue($field, $storeId = null)
    {
        $this->setDefaultMethodCode();
        if ($this->methodCode === null || $this->pathPattern === null) {
            return null;
        }

        if ($field === 'secret_key' || $field === 'publishable_key') {
            return $this->getKey($field);
        }

        $path  = sprintf($this->pathPattern, $this->methodCode, $field);
        $value = $this->getScopeConfigValue($path, $storeId);

        if ($field === 'instructions') {
            $value = nl2br($this->escaper->escapeHtml($value));
        }

        return $value;
    }

    /**
     * @return bool
     */
    public function canUseInstantPurchase()
    {
        $isActive = $this->getValue('active');

        // Support of 3D secure not implemented for instant purchase yet.
        $is3dSecure = $this->getValue('secure');

        return !(!$isActive || $is3dSecure);
    }

    /**
     * @return array
     */
    public function getSpecificCountry()
    {
        if ($this->getAllowSpecific()) {
            $specificCountry = $this->getValue('specificcountry');
            if ($specificCountry) {
                return explode(',', $specificCountry);
            }
        }

        return [];
    }

    /**
     * @return mixed
     */
    public function getAllowSpecific()
    {
        return $this->getValue('allowspecific');
    }

    /**
     * @return void
     */
    public function setDefaultMethodCode()
    {
        if (!$this->methodCode) {
            $this->methodCode = CreditCards::CODE;
        }
    }

    /**
     * @param $path
     * @param null $storeId
     *
     * @return mixed
     */
    public function getScopeConfigValue($path, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $path,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $field
     *
     * @return mixed
     */
    public function getKey($field)
    {
        $environment = $this->getCredentialConfig('environment');
        if ($environment === Environment::ENVIRONMENT_SANDBOX || !$environment) {
            $field .= '_test';
        }

        return $this->_encryptor->decrypt($this->getCredentialConfig($field));
    }

    /**
     * @param $field
     * @param null $storeId
     *
     * @return mixed
     */
    public function getCredentialConfig($field, $storeId = null)
    {
        $path = 'payment/mp_stripe_section/credential/' . $field;

        return $this->getScopeConfigValue($path, $storeId);
    }
}

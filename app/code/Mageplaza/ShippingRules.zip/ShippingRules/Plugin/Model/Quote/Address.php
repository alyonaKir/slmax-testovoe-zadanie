<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ShippingRules
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ShippingRules\Plugin\Model\Quote;

use Exception;
use Magento\Backend\Model\Session as BackendSession;
use Magento\Backend\Model\Session\Quote as QuoteSession;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\Registry;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address as QuoteAddress;
use Magento\Quote\Model\Quote\Address\Rate;
use Magento\Quote\Model\Quote\TotalsCollector;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Mageplaza\ShippingRules\Helper\Data as HelperData;
use Mageplaza\ShippingRules\Model\ResourceModel\Rule\Collection;
use Mageplaza\ShippingRules\Model\Rule;
use Mageplaza\ShippingRules\Model\RuleFactory as ShippingRuleFactory;
use Mageplaza\ShippingRules\Plugin\ShippingRulesPlugin;

/**
 * Class Address
 * @package Mageplaza\ShippingRules\Plugin\Model\Rate
 */
class Address extends ShippingRulesPlugin
{
    /**
     * @var CheckoutSession
     */
    protected $_checkoutSession;

    /**
     * @var ShippingRuleFactory
     */
    protected $_shippingRuleFactory;

    /**
     * @var array
     */
    protected $appliedRule = [];

    /**
     * @var bool
     */
    protected $ruleActive = false;

    /**
     * @var array
     */
    protected $shippingCode = [];

    /**
     * @var array
     */
    protected $shippingData = [];

    /**
     * @var array
     */
    protected $isChange = [];

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * Address constructor.
     *
     * @param Registry $coreRegistry
     * @param TotalsCollector $totalsCollector
     * @param CartRepositoryInterface $cartRepository
     * @param BackendSession $backendSession
     * @param QuoteSession $quoteSession
     * @param CheckoutSession $checkoutSession
     * @param AddressRepositoryInterface $addressRepository
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     * @param HelperData $helperData
     * @param ShippingRuleFactory $shippingRuleFactory
     * @param RequestInterface $request
     * @param DataObjectProcessor|null $dataProcessor
     */
    public function __construct(
        Registry $coreRegistry,
        TotalsCollector $totalsCollector,
        CartRepositoryInterface $cartRepository,
        BackendSession $backendSession,
        QuoteSession $quoteSession,
        CheckoutSession $checkoutSession,
        AddressRepositoryInterface $addressRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        HelperData $helperData,
        ShippingRuleFactory $shippingRuleFactory,
        RequestInterface $request,
        DataObjectProcessor $dataProcessor = null
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_shippingRuleFactory = $shippingRuleFactory;
        $this->request = $request;

        parent::__construct(
            $coreRegistry,
            $totalsCollector,
            $cartRepository,
            $backendSession,
            $quoteSession,
            $addressRepository,
            $quoteIdMaskFactory,
            $helperData,
            $dataProcessor
        );
    }

    /**
     * @param QuoteAddress $subject
     * @param callable $proceed
     *
     * @return mixed
     * @throws Exception
     * @throws NoSuchEntityException
     */
    public function aroundGetAllShippingRates(QuoteAddress $subject, callable $proceed)
    {
        $cartId = $this->_coreRegistry->registry('mp_shippingrules_cart');
        if (!$cartId || !$this->_helperData->isEnabled()) {
            return $proceed();
        }

        $this->ruleActive = false;
        $shippingRatesCollection = $proceed();

        /** @var Quote $quote */
        $quote = $this->_cartRepository->getActive($cartId);

        $totals = $this->getTotals($quote);

        if ($this->request->getFullActionName() === '__') {
            $this->resetIsChange();
            $this->resetIsMultiRule();
        }

        foreach ($this->getAppliedRule($quote) as $rule) {
            if (!$rule) {
                continue;
            }

            $appliedShippingMethod = explode(',', $rule->getShippingMethods());
            foreach ($shippingRatesCollection as $shippingRate) {
                /** @var Rate $shippingRate */
                if ($this->canUpdatePrice($shippingRate, $appliedShippingMethod, $rule, $quote->getStoreId())) {
                    $shippingRate->setPrice(
                        $this->_priceCalculation($rule, (float)$shippingRate->getPrice(), $totals, $quote)
                    );
                }
            }
        }

        return $shippingRatesCollection;
    }

    /**
     * @param QuoteAddress $subject
     * @param callable $proceed
     *
     * @return mixed
     * @throws NoSuchEntityException
     * @throws Exception
     */
    public function aroundGetGroupedAllShippingRates(QuoteAddress $subject, callable $proceed)
    {
        $cartId = $this->_coreRegistry->registry('mp_shippingrules_cart');

        if (!$cartId || !$this->_helperData->isEnabled()) {
            return $proceed();
        }

        $this->ruleActive = false;
        $shippingRatesCollection = $proceed();

        /** @var Quote $quote */
        $quote = $this->_cartRepository->getActive($cartId);

        $totals = $this->getTotals($quote);

        foreach ($this->getAppliedRule($quote) as $rule) {
            if (!$rule) {
                continue;
            }

            $appliedShippingMethod = explode(',', $rule->getShippingMethods());
            foreach ($shippingRatesCollection as $shippingRates) {
                /** @var Rate $shippingRate */
                foreach ($shippingRates as $shippingRate) {
                    if ($this->canUpdatePrice($shippingRate, $appliedShippingMethod, $rule, $quote->getStoreId())) {
                        $shippingRate->setPrice(
                            $this->_priceCalculation($rule, (float)$shippingRate->getPrice(), $totals, $quote)
                        );
                    }
                }
            }
        }

        return $shippingRatesCollection;
    }

    /**
     * @param CartInterface|Quote $quote
     *
     * @return array
     */
    public function getTotals($quote)
    {
        $shipping = $quote->getShippingAddress();

        $totals['subtotal'] = (float)$quote->getBaseSubtotal();
        $totals['discount'] = $shipping->getBaseDiscountAmount();
        $totals['final_tax'] = $shipping->getBaseTaxAmount() + $shipping->getBaseDiscountTaxCompensationAmount();

        $shipping->setCollectShippingRates(true);

        return $totals;
    }

    /**
     * @param CartInterface|Quote $quote
     *
     * @return Rule[]
     * @throws NoSuchEntityException
     * @throws Exception
     */
    public function getAppliedRule($quote)
    {
        /** @var Collection $ruleCollection */
        $ruleCollection = $this->_helperData->getShippingRuleCollection();

        $appliedSaleRuleIds = explode(',', $quote->getShippingAddress()->getAppliedRuleIds());

        /** @var Rule $rule */
        foreach ($ruleCollection as $rule) {
            if (!$this->_helperData->getScheduleFilter($rule)) {
                continue;
            }

            if ($rule->getSaleRulesInactive()) {
                $saleRuleInactive = explode(',', $rule->getSaleRulesInactive());
                if (array_intersect($saleRuleInactive, $appliedSaleRuleIds)) {
                    $this->appliedRule[] = null;
                    continue;
                }
            }

            if ($rule->getSaleRulesActive()) {
                $saleRuleActive = explode(',', $rule->getSaleRulesActive());
                if (array_intersect($saleRuleActive, $appliedSaleRuleIds)) {
                    $this->appliedRule[] = $rule;
                    if ($rule->getDiscardSubRule()) {
                        break;
                    }
                }
                continue;
            }

            if ($rule->validate($quote->getShippingAddress())) {
                $this->appliedRule[] = $rule;
                if ($rule->getDiscardSubRule()) {
                    break;
                }
            }
        }

        return $this->appliedRule;
    }

    /**
     * @param Rate $shippingRate
     * @param array $appliedShippingMethod
     * @param $rule
     * @param int $storeId
     *
     * @return bool
     */
    public function canUpdatePrice($shippingRate, $appliedShippingMethod, $rule, $storeId)
    {
        $shippingMethodCode = $shippingRate->getCode();

        if (!in_array($shippingMethodCode, $appliedShippingMethod, true)) {
            return false;
        }

        if (in_array($shippingMethodCode, $this->shippingCode, true)) {
            return false;
        }

        if (!$this->_helperData->getConfigGeneral('multi_rules', $storeId)) {
            $this->shippingCode[] = $shippingMethodCode;
        }

        if (isset($this->isChange[$rule->getId()][$shippingMethodCode])) {
            return false;
        }
        $this->isChange[$rule->getId()][$shippingMethodCode] = true;

        return true;
    }

    /**
     * Reset Is Change
     */
    public function resetIsChange()
    {
        $this->isChange = [];
    }

    /**
     * Reset Is Multi Rule
     */
    public function resetIsMultiRule()
    {
        $this->shippingCode = [];
    }
}

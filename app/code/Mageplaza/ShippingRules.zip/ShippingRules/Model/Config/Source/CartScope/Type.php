<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ShippingRules
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ShippingRules\Model\Config\Source\CartScope;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Type
 * @package Mageplaza\ShippingRules\Model\Config\Source\CartScope
 */
class Type implements ArrayInterface
{
    const DISABLE = 0;

    const PERCENTAGE_OF_ITEM_PRICE = 1;

    const FIXED_AMOUNT = 2;

    const FIXED_AMOUNT_PER_WEIGHT = 3;

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];
        foreach ($this->toArray() as $value => $label) {
            $options[] = [
                'value' => $value,
                'label' => $label
            ];
        }

        return $options;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            self::DISABLE                  => __('Disable'),
            self::PERCENTAGE_OF_ITEM_PRICE => __('Percentage of Item price'),
            self::FIXED_AMOUNT             => __('Fixed Amount'),
            self::FIXED_AMOUNT_PER_WEIGHT  => __('Fixed amount with each of weight unit')
        ];
    }
}

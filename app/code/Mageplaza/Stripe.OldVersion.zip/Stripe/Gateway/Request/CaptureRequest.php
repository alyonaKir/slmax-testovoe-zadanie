<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Request;

use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Sales\Model\Order;
use Mageplaza\Stripe\Gateway\AbstractGateway;
use Mageplaza\Stripe\Model\Source\PaymentAction;

/**
 * Class CaptureRequest
 * @package Mageplaza\Stripe\Gateway\Request
 */
class CaptureRequest extends AbstractGateway
{
    /**
     * @param PaymentDataObjectInterface $payment
     * @param Order $order
     *
     * @return array
     */
    public function processRequest($payment, $order)
    {
        $data = $this->processData($payment, $order);

        $email = '';
        if ($order->getBillingAddress()) {
            $email = $order->getBillingAddress()->getEmail();
        }

        return array_merge($data, [
            'DESCRIPTION' => sprintf('#%s, %s', $order->getOrderIncrementId(), $email),
            'AMOUNT'      => SubjectReader::readAmount($this->subjectData) * 100,
            'CURRENCY'    => strtolower($order->getCurrencyCode()),
            'PRIVATE_KEY' => $payment->getMethodInstance()->getConfigData('secret_key', $order->getStoreId()),
            'METHOD_CODE' => $payment->getMethodInstance()->getCode(),
        ]);
    }

    /**
     * @return string
     */
    public function getType()
    {
        return PaymentAction::ACTION_AUTHORIZE_CAPTURE;
    }
}

<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Request;

use InvalidArgumentException;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Sales\Model\Order;
use Mageplaza\Stripe\Gateway\AbstractGateway;

/**
 * Class RefundRequest
 * @package Mageplaza\Stripe\Gateway\Request
 */
class RefundRequest extends AbstractGateway
{
    /**
     * @param PaymentDataObjectInterface $payment
     * @param Order $order
     *
     * @return array
     */
    public function processRequest($payment, $order)
    {
        $transactionId = $payment->getParentTransactionId();

        if (!$transactionId) {
            throw new InvalidArgumentException('Transaction Id does not exist');
        }

        return [
            'SOURCE_ID'   => $transactionId,
            'TXN_TYPE'    => 'refund',
            'PRIVATE_KEY' => $this->getSecretKey($payment, $order->getStoreId())
        ];
    }
}

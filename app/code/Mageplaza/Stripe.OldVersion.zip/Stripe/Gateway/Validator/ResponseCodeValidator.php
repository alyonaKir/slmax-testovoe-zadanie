<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Validator;

use InvalidArgumentException;
use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;

/**
 * Class ResponseCodeValidator
 * @package Mageplaza\Stripe\Gateway\Validator
 */
class ResponseCodeValidator extends AbstractValidator
{
    /**
     * @param array $validationSubject
     *
     * @return ResultInterface
     * @throws InvalidArgumentException
     */
    public function validate(array $validationSubject)
    {
        if (!isset($validationSubject['response']) || !is_array($validationSubject['response'])) {
            throw new InvalidArgumentException(__('Response does not exist'));
        }

        $response = $validationSubject['response'];

        if (isset($response['TXN_ID']) && $response['TXN_ID']) {
            return $this->createResult(true);
        }

        return $this->createResult(false, [__('Gateway rejected the transaction.')]);
    }
}

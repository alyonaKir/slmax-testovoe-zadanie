<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Response;

use DateInterval;
use DateTime;
use DateTimeZone;
use Exception;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterfaceFactory;
use Magento\Vault\Api\Data\PaymentTokenFactoryInterface;
use Magento\Vault\Api\Data\PaymentTokenInterface;
use Mageplaza\Stripe\Gateway\AbstractGateway;
use Mageplaza\Stripe\Model\Source\CardType;

/**
 * Class VaultDetailsHandler
 * @package Mageplaza\Stripe\Gateway\Response
 */
class VaultDetailsHandler extends AbstractGateway
{
    /**
     * @var PaymentTokenFactoryInterface
     */
    protected $paymentTokenFactory;

    /**
     * @var OrderPaymentExtensionInterfaceFactory
     */
    protected $paymentExtensionFactory;

    /**
     * @var Json
     */
    private $serializer;

    /**
     * @var CardType
     */
    protected $creditCardType;

    /**
     * VaultDetailsHandler constructor.
     *
     * @param Registry $registry
     * @param PaymentTokenFactoryInterface $paymentTokenFactory
     * @param OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory
     * @param CardType $creditCardType
     * @param Json|null $serializer
     */
    public function __construct(
        Registry $registry,
        PaymentTokenFactoryInterface $paymentTokenFactory,
        OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory,
        CardType $creditCardType,
        Json $serializer = null
    ) {
        parent::__construct($registry);
        $this->creditCardType          = $creditCardType;
        $this->paymentTokenFactory     = $paymentTokenFactory;
        $this->paymentExtensionFactory = $paymentExtensionFactory;
        $this->serializer              = $serializer ?: ObjectManager::getInstance()->get(Json::class);
    }

    /**
     * @param PaymentDataObjectInterface $payment
     * @param array $response
     *
     * @return $this|AbstractGateway
     * @throws Exception
     */
    public function processResponse($payment, $response)
    {
        $additionalInformation = $payment->getAdditionalInformation();
        if ($response['IS_SAVE_CARD']) {
            $paymentToken = $this->getVaultPaymentToken($additionalInformation);
            if ($paymentToken !== null) {
                $extensionAttributes = $this->getExtensionAttributes($payment);
                $extensionAttributes->setVaultPaymentToken($paymentToken);
            }
        }

        return $this;
    }

    /**
     * @param $additionalInformation
     *
     * @return PaymentTokenInterface|null
     * @throws Exception
     */
    protected function getVaultPaymentToken($additionalInformation)
    {
        if (isset($additionalInformation['source_id']) && $additionalInformation['source_id']) {
            /** @var PaymentTokenInterface $paymentToken */
            $paymentToken = $this->paymentTokenFactory->create(PaymentTokenFactoryInterface::TOKEN_TYPE_CREDIT_CARD);
            $paymentToken->setGatewayToken($additionalInformation['source_id']);

            $paymentToken->setExpiresAt($this->getExpirationDate($additionalInformation));
            $paymentToken->setIsVisible(1);
            $type = $this->creditCardType->getCreditCardsMapper($additionalInformation['mp_card_brand']);
            $paymentToken->setTokenDetails(
                $this->convertDetailsToJSON(
                    [
                        'type'           => $type,
                        'maskedCC'       => $additionalInformation['mp_card_last4'],
                        'expirationDate' => $additionalInformation['mp_card_exp_month'] . '/' .
                            $additionalInformation['mp_card_exp_year']
                    ]
                )
            );

            return $paymentToken;
        }

        return null;
    }

    /**
     * @param array $reponse
     *
     * @return string
     * @throws Exception
     */
    private function getExpirationDate($reponse)
    {
        $expDate = new DateTime(
            $reponse['mp_card_exp_year']
            . '-'
            . $reponse['mp_card_exp_month']
            . '-'
            . '01'
            . ' '
            . '00:00:00',
            new DateTimeZone('UTC')
        );
        $expDate->add(new DateInterval('P1M'));

        return $expDate->format('Y-m-d 00:00:00');
    }

    /**
     * Convert payment token details to JSON
     *
     * @param array $details
     *
     * @return string
     */
    private function convertDetailsToJSON($details)
    {
        $json = $this->serializer->serialize($details);

        return $json ?: '{}';
    }

    /**
     * @param PaymentDataObjectInterface $payment
     *
     * @return mixed
     */
    private function getExtensionAttributes($payment)
    {
        $extensionAttributes = $payment->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->paymentExtensionFactory->create();
            $payment->setExtensionAttributes($extensionAttributes);
        }

        return $extensionAttributes;
    }
}

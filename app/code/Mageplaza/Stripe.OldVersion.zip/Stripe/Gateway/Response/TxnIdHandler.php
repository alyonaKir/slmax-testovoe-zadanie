<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Gateway\Response;

use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Mageplaza\Stripe\Gateway\AbstractGateway;
use Mageplaza\Stripe\Model\Source\PaymentAction;

/**
 * Class TxnIdHandler
 * @package Mageplaza\Stripe\Gateway\Response
 */
class TxnIdHandler extends AbstractGateway
{
    /**
     * @param PaymentDataObjectInterface $payment
     * @param array $response
     *
     * @return $this|AbstractGateway
     */
    public function processResponse($payment, $response)
    {
        if ($response['TXN_TYPE'] === PaymentAction::ACTION_AUTHORIZE_CAPTURE) {
            $payment->setTransactionId($response['TXN_ID']);
            $payment->setIsTransactionClosed(false);
        }

        if (isset($response['IDIAL_INFO'])) {
            $paymentInfoKeys = $payment->getMethodInstance()->getPaymentInfoKeys();
            $iDEALInfo       = $response['IDIAL_INFO'];
            foreach ($paymentInfoKeys as $key) {
                if (isset($iDEALInfo[$key])) {
                    $payment->setAdditionalInformation($key, $iDEALInfo[$key]);
                }
            }
        }

        if ($response['TXN_TYPE'] === 'refund') {
            $payment->setTransactionId($response['TXN_ID'])
                ->setIsTransactionClosed(1)
                ->setShouldCloseParentTransaction(1);
        } else {
            $payment->setAdditionalInformation('source_id', $response['SOURCE_ID']);
        }

        return $this;
    }
}

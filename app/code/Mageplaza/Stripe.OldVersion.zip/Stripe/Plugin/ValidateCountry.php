<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Plugin;

use Magento\Customer\Model\Customer;
use Magento\Customer\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Vault\Api\Data\PaymentTokenSearchResultsInterface;
use Magento\Vault\Model\PaymentTokenRepository;
use Mageplaza\Stripe\Gateway\Config\Config;
use Mageplaza\Stripe\Model\Payment\CreditCards;

/**
 * Class ValidateCountry
 * @package Mageplaza\Stripe\Plugin
 */
class ValidateCountry
{
    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * ValidateCountry constructor.
     *
     * @param Session $customerSession
     * @param Config $config
     * @param RequestInterface $request
     */
    public function __construct(
        Session $customerSession,
        Config $config,
        RequestInterface $request
    ) {
        $this->customerSession = $customerSession;
        $this->config          = $config;
        $this->request         = $request;
    }

    /**
     * @param PaymentTokenRepository $subject
     * @param PaymentTokenSearchResultsInterface $result
     *
     * @return PaymentTokenSearchResultsInterface
     */
    public function afterGetList(PaymentTokenRepository $subject, $result)
    {
        if ($this->request->getFullActionName() === 'customer_section_load' &&
            $this->request->getParam('sections') === 'instant-purchase') {
            /** @var Customer $customer */
            $customer = $this->customerSession->getCustomer();
            if ($result->getItems() && $customer && $customer->getId()) {
                $countryId = $customer->getDefaultBillingAddress()->getCountryId();
                $items     = [];
                foreach ($result->getItems() as $item) {
                    $specificCountry = $this->config->getSpecificCountry();
                    if ($specificCountry && $item->getPaymentMethodCode() === CreditCards::CODE &&
                        !in_array($countryId, $specificCountry, true)) {
                        continue;
                    }

                    $items[] = $item;
                }

                $result->setItems($items);
            }
        }

        return $result;
    }
}

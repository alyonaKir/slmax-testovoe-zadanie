<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Plugin;

use Magento\Framework\App\Area;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order\Invoice\Item;
use Mageplaza\Stripe\Helper\Data;

/**
 * Class InvoiceItem
 * @package Mageplaza\Stripe\Plugin
 */
class InvoiceItem
{
    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * @var State
     */
    protected $state;

    /**
     * InvoiceItem constructor.
     *
     * @param RequestInterface $request
     * @param Data $helperData
     * @param State $state
     */
    public function __construct(RequestInterface $request, Data $helperData, State $state)
    {
        $this->request    = $request;
        $this->helperData = $helperData;
        $this->state      = $state;
    }

    /**
     * Fix bug magento 2.3.1 when preparing invoice item
     *
     * @param Item $subject
     * @param string $qty
     *
     * @return array
     * @throws LocalizedException
     */
    public function beforeSetQty(Item $subject, $qty)
    {
        $fullActionName = $this->request->getFullActionName();
        $areaCode       = $this->state->getAreaCode();
        if ($this->helperData->isVersion231()) {
            if ($fullActionName === 'mpstripe_index_placeorder' || $areaCode === Area::AREA_WEBAPI_REST) {
                $qtyOrdered = $subject->getOrderItem()->getQtyOrdered();

                if ((int) $qty !== $qtyOrdered) {
                    return [$qtyOrdered];
                }
            }
        }

        return [$qty];
    }
}

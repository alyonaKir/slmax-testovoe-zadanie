<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Controller\Payment;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Vault\Model\PaymentTokenFactory;
use Mageplaza\Stripe\Gateway\Config\Config;
use Stripe\Source;
use Stripe\Stripe;

/**
 * Class PlaceOrder
 * @package Mageplaza\Stripe\Controller\Index
 */
class Check3d extends Action
{
    /**
     * @var Config
     */
    protected $config;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var PaymentTokenFactory
     */
    protected $paymentTokenFactory;

    /**
     * Check3d constructor.
     *
     * @param Context $context
     * @param Config $config
     * @param PaymentTokenFactory $paymentTokenFactory
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context,
        Config $config,
        PaymentTokenFactory $paymentTokenFactory,
        JsonFactory $resultJsonFactory
    ) {
        $this->config              = $config;
        $this->resultJsonFactory   = $resultJsonFactory;
        $this->paymentTokenFactory = $paymentTokenFactory;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|Json|ResultInterface
     */
    public function execute()
    {
        $result['status']  = false;
        $result['message'] = '';
        try {
            Stripe::setApiKey($this->config->getKey('secret_key'));
            $publicHash   = $this->getRequest()->getParam('public_hash');
            $paymentToken = $this->paymentTokenFactory->create()->load($publicHash, 'public_hash');
            if ($paymentToken->getId()) {
                $source = Source::retrieve($paymentToken->getGatewayToken());
                if (isset($source['id'])) {
                    $result['status']         = true;
                    $result['source']['id']   = $source['id'];
                    $result['source']['card'] = $source['card'];
                } else {
                    $result['message'] = __('Source id not found!');
                }
            } else {
                $result['message'] = __('Payment token not found!');
            }
        } catch (Exception $e) {
            $result['message'] = $e->getMessage();
        }

        /** @var Json $resultJson */
        $resultJson = $this->resultJsonFactory->create();

        return $resultJson->setData($result);
    }
}

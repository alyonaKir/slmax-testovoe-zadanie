<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Block;

use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Mageplaza\Stripe\Helper\Data;

/**
 * Class InstancePurchase
 * @package Mageplaza\Stripe\Block
 */
class InstancePurchase extends Template
{
    /**
     * @var Context
     */
    protected $httpContext;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * InstancePurchase constructor.
     *
     * @param Context $context
     * @param HttpContext $httpContext
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        HttpContext $httpContext,
        Data $helperData,
        array $data = []
    ) {
        $this->httpContext = $httpContext;
        $this->helperData  = $helperData;

        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function toHtml()
    {
        $html = '';
        if ($this->helperData->canReloadInstancePurchase()) {
            //Check customer login when cache enable
            $isCustomerLogin = $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);

            if ($isCustomerLogin) {
                $html = "<p data-mage-init='{
                        \"Mageplaza_Stripe/js/view/reload-section\": {\"section\":[\"instant-purchase\"]}
                    }'
               >&nbsp;</p>";
            }
        }

        return parent::toHtml() . $html;
    }
}

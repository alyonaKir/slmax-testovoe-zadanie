<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Block;

use Magento\Payment\Block\ConfigurableInfo;

/**
 * Class Info
 * @package Mageplaza\Stripe\Block
 */
class Info extends ConfigurableInfo
{
    /**
     * @param string $field
     *
     * @return mixed
     */
    protected function getLabel($field)
    {
        return $this->labels()[$field];
    }

    /**
     * @return array
     */
    public function labels()
    {
        return [
            'mp_card_last4'     => __('Last Card Number'),
            'mp_card_exp_month' => __('Month End'),
            'mp_card_exp_year'  => __('Year End'),
            'mp_card_brand'     => __('Brand')
        ];
    }
}

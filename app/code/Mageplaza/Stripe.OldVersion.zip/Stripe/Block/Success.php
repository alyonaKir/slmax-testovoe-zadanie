<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Block;

use Magento\Sales\Model\Order;
use Mageplaza\Stripe\Model\StripePayment;

/**
 * Class Success
 * @package Mageplaza\Stripe\Block
 */
class Success extends \Magento\Checkout\Block\Onepage\Success
{
    /**
     * @return string
     */
    protected function _toHtml()
    {
        /** @var Order $order */
        $order = $this->_checkoutSession->getLastRealOrder();

        if ($order->getPayment()) {
            $method = $order->getPayment()->getMethodInstance();
            if ($method instanceof StripePayment) {
                return "<p data-mage-init='{
                        \"Mageplaza_Stripe/js/view/reload-section\": {\"section\":[\"cart\",\"checkout-data\"]}
                    }'
               >&nbsp;</p>";
            }
        }

        return '';
    }
}

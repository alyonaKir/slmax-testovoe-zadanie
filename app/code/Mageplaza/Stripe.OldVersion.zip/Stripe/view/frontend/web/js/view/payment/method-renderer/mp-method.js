/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'ko',
        'Magento_Checkout/js/view/payment/default',
        'mage/translate',
        'Mageplaza_Stripe/js/model/stripe-method'
    ],
    function (ko, Component, Translate, StripeModel) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Mageplaza_Stripe/payment/mp_stripe'
            },
            type: '',
            returnUrl: '',
            getInstructions: '',
            mpStripe: '',
            placeOrderTitle: Translate('Place Order'),
            additionData: '',
            initialize: function () {
                this._super();
                var config = window.checkoutConfig.payment[this.index];
                if (config) {
                    this.returnUrl = config.return_url;
                    this.placeOrderTitle = config.placeOrderTitle;
                    this.getInstructions = config.instructions;
                }
                this.mpStripe = StripeModel.initPublishKey();
                return this;
            },

            /**
             * @return {exports.initObservable}
             */
            initObservable: function () {
                this._super()
                    .observe({
                        isShowPayment: ko.observable(true)
                    });

                return this;
            },

            /**
             * @returns {exports}
             */
            mpStripePlaceOrder: function (data, event) {
                if (event) {
                    event.preventDefault();
                }

                StripeModel.createSource(
                    this.messageContainer,
                    this.getData(),
                    this.type,
                    this.returnUrl,
                    false,
                    this.additionData
                );

                return this;
            },

            /**
             * @param data
             * @param source
             * @returns {*}
             */
            setCardInfo: function (data, source) {
                var additionalData = {};
                if (data.additional_data === null) {
                    data.additional_data = {};
                }

                if (source) {
                    additionalData = {
                        source_id: source.id,
                        mp_card_brand: source.card.brand,
                        mp_card_exp_month: source.card.exp_month,
                        mp_card_exp_year: source.card.exp_year,
                        mp_card_last4: source.card.last4
                    };

                    data.additional_data = _.extend(additionalData, data.additional_data);
                }

                return data;
            }
        });
    }
);
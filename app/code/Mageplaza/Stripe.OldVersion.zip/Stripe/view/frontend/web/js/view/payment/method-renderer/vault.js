/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define([
    'jquery',
    'Magento_Vault/js/view/payment/method-renderer/vault',
    'Mageplaza_Stripe/js/model/stripe-method'
], function ($, VaultComponent, StripeModel) {
    'use strict';

    return VaultComponent.extend({
        defaults: {
            template: 'Magento_Vault/payment/form'
        },
        /**
         * Get last 4 digits of card
         * @returns {String}
         */
        getMaskedCard: function () {
            return this.details.maskedCC;
        },

        /**
         * Get expiration date
         * @returns {String}
         */
        getExpirationDate: function () {
            return this.details.expirationDate;
        },

        /**
         * Get card type
         * @returns {String}
         */
        getCardType: function () {
            return this.details.type;
        },
        /**
         *
         * @returns {*}
         */
        getData: function () {
            var data = this._super();

            data.additional_data = _.extend(data.additional_data, {public_hash: this.publicHash});
            return data;
        },

        check3dSecure: function (mpStripeCreditCards) {
            var self = this;
            $.ajax({
                method: "POST",
                url: this.secureUrl,
                data: {public_hash: this.publicHash},
                success: function (response) {
                    if (response.status) {
                        var status = StripeModel.process3DSecure(
                            response,
                            self.messageContainer,
                            mpStripeCreditCards,
                            self.getData()
                        );

                        if (!status.isShowMessage && !status.isPlace3D) {
                            self.placeOrder();
                        }
                    } else {
                        self.messageContainer.addErrorMessage({
                            message: response.message
                        });
                    }
                }
            });
        },

        /**
         * Place order
         */
        placeOrder: function () {
            var mpStripeCreditCards = window.checkoutConfig.payment.mp_stripe_credit_cards;
            if (mpStripeCreditCards.isSecure) {
                this.check3dSecure(mpStripeCreditCards);
            } else {
                this._super();
            }
        }
    });
});
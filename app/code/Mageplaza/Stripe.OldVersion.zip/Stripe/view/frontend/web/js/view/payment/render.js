/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (Component, rendererList) {
        'use strict';

        rendererList.push(
            {
                type: 'mp_stripe_credit_cards',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-credit-cards-method'
            },
            {
                type: 'mp_stripe_alipay',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-alipay-method'
            },
            {
                type: 'mp_stripe_giropay',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-giropay-method'
            },
            {
                type: 'mp_stripe_bancontact',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-bancontact-method'
            },
            {
                type: 'mp_stripe_przelewy24',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-przelewy24-method'
            },
            {
                type: 'mp_stripe_sofort',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-sofort-method'
            },
            {
                type: 'mp_stripe_eps',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-eps-method'
            },
            {
                type: 'mp_stripe_ideal',
                component: 'Mageplaza_Stripe/js/view/payment/method-renderer/mp-ideal-method'
            }
        );

        /**
         * Detect current browser
         */
        var browser = (function () {
            var ua = navigator.userAgent, tem,
                MatchResult = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if (/trident/i.test(MatchResult[1])) {
                tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                return 'IE ' + (tem[1] || '');
            }
            if (MatchResult[1] === 'Chrome') {
                tem = ua.match(/\b(OPR|Edge?)\/(\d+)/);
                if (tem != null) {
                    return tem.slice(1).join(' ').replace('OPR', 'Opera').replace('Edg ', 'Edge ');
                }
            }
            MatchResult = MatchResult[2] ? [MatchResult[1], MatchResult[2]] : [navigator.appName, '-?'];
            if ((tem = ua.match(/version\/(\d+)/i)) != null) MatchResult.splice(1, 1, tem[1]);
            return MatchResult.join(' ');
        })();

        var type = '';
        if (browser.indexOf('Chrome') !== -1) {
            type = 'mp_stripe_google_pay';
        } else if (browser.indexOf('Edge') !== -1) {
            type = 'mp_stripe_microsoft_pay';
        } else if (browser.indexOf('Safari') !== -1) {
            type = 'mp_stripe_apple_pay';
        }

        if (type) {
            var requestButtonFileName = 'mp-request-button-method';
            if (window.checkoutConfig.oscConfig) {
                requestButtonFileName = 'compatible/' + requestButtonFileName;
            }
            rendererList.push(
                {
                    type: type,
                    component: 'Mageplaza_Stripe/js/view/payment/method-renderer/' + requestButtonFileName
                }
            );
        }

        return Component.extend({});
    }
);
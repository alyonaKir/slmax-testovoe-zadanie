/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/action/set-payment-information',
    'mage/translate',
    'https://js.stripe.com/v3/'
], function ($, Quote, Loader, additionalValidators, setPaymentInformation, Translate) {
    'use strict';

    return {
        mpStripe: '',
        idealBank: '',

        /**
         * @returns {*}
         */
        initPublishKey: function () {
            if (!this.mpStripe) {
                this.mpStripe = Stripe(window.checkoutConfig.payment.mp_stripe_publishable_key);
            }

            return this.mpStripe
        },
        /**
         * @param key
         * @returns {*}
         */
        getQuoteDataByKey: function (key) {
            var total = Quote.getTotals();
            return total()[key];
        },

        /**
         * @returns {string}
         */
        getCurrency: function () {
            return this.getQuoteDataByKey('base_currency_code').toLowerCase();
        },

        /**
         * @returns {number}
         */
        getAmount: function () {
            var baseGrandTotal = this.getQuoteDataByKey('base_grand_total');

            return Math.round(baseGrandTotal * 100);
        },

        /**
         * @returns {*|null}
         */
        getCustomerEmail: function () {
            if (Quote.guestEmail) {
                return Quote.guestEmail;
            }

            return window.checkoutConfig.customerData.email;
        },
        /**
         * @returns {{owner: {name: string, email: (*|null), address: {line1, city, postal_code, country: (string|*), state}}}}
         */
        getSourceAddress: function () {
            var billingAddress = Quote.billingAddress();
            if (!billingAddress.street) {
                billingAddress.street = [];
            }
            return {
                owner: {
                    name: billingAddress.firstname + ' ' + billingAddress.lastname,
                    email: this.getCustomerEmail(),
                    phone: billingAddress.telephone,
                    address: {
                        line1: billingAddress.street[0],
                        line2: billingAddress.street[1] ? billingAddress.street[1] : '',
                        city: billingAddress.city,
                        postal_code: billingAddress.postcode,
                        country: billingAddress.countryId,
                        state: billingAddress.region
                    }
                }
            }
        },

        /**
         * @param returnUrl
         * @returns {*|{owner: {name: string, email: (*|null), address: {line1, city, postal_code, country: (string|*), state}}}}
         */
        getSourceIDEAL: function (returnUrl) {
            var sourceAddress = this.getSourceAddress();
            sourceAddress.type = 'ideal';
            sourceAddress.amount = this.getAmount();
            sourceAddress.currency = this.getCurrency();
            sourceAddress.redirect = {return_url: returnUrl};

            return sourceAddress;
        },

        setIdealBank: function (idealBank) {
            this.idealBank = idealBank;
        },

        /**
         * @param response
         * @param messageContainer
         * @returns {*}
         */
        processResponse: function (response, messageContainer) {
            if (response.error) {
                messageContainer.addErrorMessage(response.error);
            } else {
                return $(location).attr('href', response.source.redirect.url);
            }

            return this;
        },

        /**
         * @param response
         * @param messageContainer
         * @param mpStripeCreditCards
         * @param data
         * @returns {{isShowMessage: boolean, isPlace3D: boolean}}
         */
        process3DSecure: function (response, messageContainer, mpStripeCreditCards, data) {
            var threeDSecure = response.source.card.three_d_secure;
            var isShowMessage = false;

            if (threeDSecure === 'not_supported') {
                messageContainer.addErrorMessage({
                    message: Translate('This card does not support 3D Secure.')
                });
                isShowMessage = true;
            }

            var isCardSupport3D = false;

            if (
                threeDSecure === 'required' ||
                (
                    mpStripeCreditCards.foreUsing &&
                    mpStripeCreditCards.secureWhen.indexOf(threeDSecure) !== -1
                )
            ) {
                isCardSupport3D = true;
            }

            if (isCardSupport3D) {
                this.createSource(
                    messageContainer,
                    data,
                    'three_d_secure',
                    mpStripeCreditCards.return_url,
                    true,
                    {card: response.source.id}
                );
            }

            return {isShowMessage: isShowMessage, isPlace3D: isCardSupport3D};
        },

        /**
         * @param messageContainer
         * @param data
         * @param type
         * @param returnUrl
         * @param threeDSecure
         * @param additionData
         */
        createSource: function (messageContainer, data, type, returnUrl, threeDSecure, additionData) {
            var self = this;
            if (additionalValidators.validate()) {
                $.when(setPaymentInformation(messageContainer, data)).done(function () {
                    if (!threeDSecure) {
                        Loader.startLoader();
                    }

                    var sourceData = {
                        type: type,
                        amount: self.getAmount(),
                        currency: self.getCurrency(),
                        redirect: {
                            return_url: returnUrl
                        }
                    };

                    if (type === 'ideal') {
                        sourceData = $.extend({}, sourceData, self.getSourceAddress());
                        self.mpStripe.createSource(self.idealBank, sourceData).then(function (response) {
                            self.processResponse(response, messageContainer);

                            Loader.stopLoader();
                        });

                        return;
                    }

                    if (threeDSecure) {
                        sourceData.three_d_secure = additionData;
                        additionData = '';
                    } else {
                        sourceData.owner = self.getSourceAddress().owner;
                    }

                    if (additionData) {
                        sourceData = $.extend({}, sourceData, additionData);
                    }


                    self.mpStripe.createSource(sourceData).then(function (response) {
                        self.processResponse(response, messageContainer);
                        if (!threeDSecure) {
                            Loader.stopLoader();
                        }
                    });
                });
            }
        }
    }
});
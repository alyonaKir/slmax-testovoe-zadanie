<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\UrlInterface;
use Magento\Payment\Model\Method\Adapter;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\PaymentInterface;

/**
 * Class StripePayment
 * @package Mageplaza\Stripe\Model
 */
class StripePayment extends Adapter
{
    /**
     * @var UrlInterface
     */
    protected $_urlBuilder;

    /**
     * Assign data to info model instance
     *
     * @param array|DataObject $data
     *
     * @return $this
     * @throws LocalizedException
     */
    public function assignData(DataObject $data)
    {
        parent::assignData($data);

        $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);
        if (!is_array($additionalData)) {
            return $this;
        }

        $paymentInfoKeys   = $this->getPaymentInfoKeys();
        $paymentInfoKeys[] = 'source_id';
        $paymentInfoKeys[] = 'is_active_payment_token_enabler';
        foreach ($paymentInfoKeys as $key) {
            if (isset($additionalData[$key])) {
                $this->getInfoInstance()->setAdditionalInformation(
                    $key,
                    $additionalData[$key]
                );
            }
        }

        return $this;
    }

    /**
     * @param CartInterface|null $quote
     *
     * @return bool|mixed
     */
    public function isAvailable(CartInterface $quote = null)
    {
        $publishableKey = $this->getConfigData('publishable_key');
        $secretKey      = $this->getConfigData('secret_key');

        return parent::isAvailable($quote) && $publishableKey && $secretKey;
    }

    /**
     * @param string|null $storeId
     *
     * @return mixed
     */
    public function getPublishableKey($storeId = null)
    {
        return $this->getConfigData('publishable_key', $storeId);
    }

    /**
     * @return mixed
     */
    public function getPaymentInfoKeys()
    {
        return $this->configToArray($this->getConfigData('paymentInfoKeys'));
    }

    /**
     * @param string $data
     *
     * @return array
     */
    public function configToArray($data)
    {
        return explode(',', $data);
    }

    /**
     * @return mixed
     */
    public function getInstructions()
    {
        return $this->getConfigData('instructions');
    }

    /**
     * @return UrlInterface|mixed
     */
    public function getUrlBuilder()
    {
        if (!$this->_urlBuilder) {
            $this->_urlBuilder = ObjectManager::getInstance()->get(UrlInterface::class);
        }

        return $this->_urlBuilder;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        return [
            'return_url'      => $this->getReturnUrl(),
            'placeOrderTitle' => $this->getPlaceOrderTitle(),
            'instructions'    => $this->getInstructions()
        ];
    }

    /**
     * @return mixed
     */
    public function getReturnUrl()
    {
        return $this->getUrlBuilder()->getUrl('mpstripe/index/placeorder');
    }

    /**
     * @return mixed
     */
    public function getPlaceOrderTitle()
    {
        return __('Place Order');
    }
}

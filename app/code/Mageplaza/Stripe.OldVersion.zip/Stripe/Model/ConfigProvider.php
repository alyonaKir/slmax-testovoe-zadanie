<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Stripe
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Stripe\Model;

use Magento\Checkout\Model\ConfigProviderInterface;

/**
 * Class ConfigProvider
 */
class ConfigProvider implements ConfigProviderInterface
{
    /**
     * @var array
     */
    private $paymentProviders;

    /**
     * ConfigProvider constructor.
     *
     * @param array $paymentProviders
     */
    public function __construct(array $paymentProviders)
    {
        $this->paymentProviders = $paymentProviders;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        $currentPayments = [];
        $payments        = $this->getPaymentProviders();
        $publishableKey  = '';
        foreach ($payments as $payment) {
            if (!$publishableKey) {
                $publishableKey                               = $payment->getPublishableKey();
                $currentPayments['mp_stripe_publishable_key'] = $publishableKey;
            }
            $currentPayments[$payment->getCode()] = $payment->getConfig();
        }

        return ['payment' => $currentPayments];
    }

    /**
     * @return array
     */
    public function getPaymentProviders()
    {
        return $this->paymentProviders;
    }
}
